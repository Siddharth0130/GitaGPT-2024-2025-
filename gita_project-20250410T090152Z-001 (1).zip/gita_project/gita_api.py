# ✅ Install dependencies first in Colab (if not done)
# !pip install flask cohere faiss-cpu sentence-transformers

import os
import json
import re
import numpy as np
import faiss
from flask import Flask, request, jsonify
from sentence_transformers import SentenceTransformer
import cohere

# Setup
app = Flask(__name__)
load_path = "/content/drive/MyDrive/gita_project/"

# Load index, texts, and metadata
index = faiss.read_index(load_path + "gita_index.faiss")

with open(load_path + "gita_texts.json", "r", encoding="utf-8") as f:
    texts = json.load(f)

with open(load_path + "gita_records.json", "r", encoding="utf-8") as f:
    records = json.load(f)

with open(load_path + "chapter_summaries.json", "r", encoding="utf-8") as f:
    chapter_summaries_raw = json.load(f)

chapter_summaries = {int(k): v for k, v in chapter_summaries_raw.items()}
id_map = {i: records[i] for i in range(len(records))}

model = SentenceTransformer("all-MiniLM-L6-v2")

# Replace with your real Cohere API key
os.environ["COHERE_API_KEY"] = "j92ZwLSyxUJzU80UHBbldJ7gUVodVqkmYQaEcqjS"
co = cohere.Client(os.getenv("COHERE_API_KEY"))

# Helper functions
def detect_query_type(query):
    query = query.lower()
    if any(kw in query for kw in ["word meaning", "शब्द", "explain word"]):
        return "word_meaning"
    elif any(kw in query for kw in ["hindi", "अर्थ", "मतलब", "हिंदी"]):
        return "hindi_meaning"
    elif any(kw in query for kw in ["shloka", "sanskrit", "original", "श्लोक"]):
        return "shloka"
    elif any(kw in query for kw in ["summary", "message of chapter", "explain chapter"]):
        return "chapter_summary"
    elif any(kw in query for kw in ["list chapters", "chapter names", "all chapters"]):
        return "list_chapters"
    else:
        return "english_meaning"

def extract_verse_reference(query):
    match = re.search(r'(\d+)\.(\d+)', query)
    if match:
        return f"{match.group(1)}.{match.group(2)}"
    return None

def extract_chapter_number(query):
    match = re.search(r'(chapter|adhyaya)\s*(\d+)', query.lower())
    if match:
        return int(match.group(2))
    return None

def generate_final_answer(query, retrieved_text):
    prompt = f"""You are a helpful assistant that answers questions based on the Bhagavad Gita.
Answer the following user question using the retrieved text.

User question: {query}

Retrieved data:
{retrieved_text}

Answer:"""

    response = co.chat(
        model="command-nightly",
        message=prompt,
        temperature=0.7,
        max_tokens=1500
    )
    return response.text.strip()

def search_verses(query, top_k=3):
    query_type = detect_query_type(query)

    if query_type == "chapter_summary":
        chapter_num = extract_chapter_number(query)
        if chapter_num and chapter_num in chapter_summaries:
            summary_data = chapter_summaries[chapter_num]
            title = summary_data.get("title", f"Chapter {chapter_num}")
            summary = summary_data.get("summary", "No summary available.")
            retrieved_text = f"""🕉️ Chapter {chapter_num}: {title}
📝 Summary: {summary}"""
            return generate_final_answer(query, retrieved_text)
        return f"❌ No summary found for chapter {chapter_num}."

    if query_type == "list_chapters":
        chapter_lines = []
        for chapter_num in sorted(chapter_summaries):
            chapter = chapter_summaries[chapter_num]
            title = chapter.get("title", f"Chapter {chapter_num}")
            chapter_lines.append(f"{chapter_num}. {title}")
        retrieved_text = "🕉️ Chapters:
" + "
".join(chapter_lines)
        return generate_final_answer(query, retrieved_text)

    verse_id = extract_verse_reference(query)
    if verse_id:
        results = [rec for rec in records if rec['id'] == verse_id]
        if not results:
            return f"❌ No verse found for ID {verse_id}"
    else:
        query_embedding = model.encode([query], convert_to_numpy=True)
        D, I = index.search(np.array(query_embedding), top_k)
        results = [id_map[i] for i in I[0]]

    output_blocks = []
    for res in results:
        vid = res['id']
        context = res.get('context', '')
        meta = res.get('metadata', {})

        answer = meta.get(query_type) or "❌ No data available for this query type."
        shloka = meta.get("transliteration", "")
        eng = res.get("text", "").split("Commentary")[0].strip()
        commentary = meta.get("commentary", "")

        block = f"""📖 Verse: {vid} ({context})
🕉️ Shloka: {shloka}
💬 Answer: {answer}
📘 English Meaning: {eng}
🧠 Commentary: {commentary}"""
        output_blocks.append(block)

    retrieved_text = "

".join(output_blocks)
    return generate_final_answer(query, retrieved_text)

# 🌐 API Endpoint
@app.route("/query", methods=["POST"])
def query_gita():
    data = request.get_json()
    question = data.get("question", "")
    if not question:
        return jsonify({"error": "Missing 'question' field."}), 400
    answer = search_verses(question)
    return jsonify({"question": question, "answer": answer})

# 🧪 Run the Flask app
if __name__ == "__main__":
    app.run(port=5000)
